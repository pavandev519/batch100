from fastapi import (
 BackgroundTasks, 
 File, 
 FastAPI,
 UploadFile,
 HTTPException,
 Form,  
 status, 
)
from pydantic import BaseModel, Json
from datetime import datetime
from fastapi import (
    APIRouter,
    Depends,
    Query,
    Body,
)
from fastapi.responses import StreamingResponse,JSONResponse
from pydantic import (
    BaseModel,
    Field,
    ValidationError
)
from typing import (List,Optional)
from typing_extensions import (
    Annotated,
    Literal
)
from logging import Logger
from models import (
    CompleteQryModel,
    GenAiCortexAudit,
    Txt2SqlModel,
    AgentModel,
    SqlExecModel,
    SearchModel,
    AnalystModel,
    LoadVectorModel,
    UploadFileModel,
    PageLoadModel,
    PromptModel, 
    FrequentQuestionModel,
    AgentListModel,
    CreateThreadModel
)
from prompts import (
    get_conv_response,
)
from config import GenAiEnvSettings
from dependencies import (
    get_config,
    get_logger,
    get_load_timestamp,
    ValidApiKey,
    SnowFlakeConnector,
    log_response,
    update_log_response,
    get_cortex_search_details,
    get_cortex_analyst_details,
    get_load_vector_data,
    get_mcp_config
)
#from ReduceReuseRecycleGENAI.api import get_api_key
from ReduceReuseRecycleGENAI.snowflake import (
    snowflake_conn,
    get_sf_database_name,
)
import httpx
import json
import uuid
import requests
import re
from functools import partial
from upload_your_data import read_file_extract
route_utils = APIRouter(
    prefix="/api/cortex"
)
from   snowflake.connector.errors import DatabaseError
from datetime import datetime, date
import snowflake.connector
from decimal import Decimal

from mcp import ClientSession
from pathlib import Path
from mcp.client.sse import sse_client
#from config import get_config

@route_utils.post("/txt2sql/run_sql_query")
async def run_sql_query(
    query: Annotated[SqlExecModel, Body(embed=True)],
    config: Annotated[GenAiEnvSettings, Depends(get_config)],
    logger: Annotated[Logger, Depends(get_logger)],
    background_tasks: BackgroundTasks
):
    api_validator = ValidApiKey()
    if api_validator(query.api_key, query.aplctn_cd, query.app_id):
        try:
            # Establish Snowflake connection
            sf_conn = SnowFlakeConnector.get_conn(
                query.aplctn_cd,
                query.app_lvl_prefix,
                query.session_id
            )
        except DatabaseError as e:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="User not authorized to resources"
            )
    # user_nm = query.user_nm
    # user_pwd = query.user_pwd
    # db_name = query.database_nm
    # role_nm = "D01_RSTRCTRD_EDA_GENAI_SUPPORTCBT_CORTEX_DVLPR_NOGBD"#f'{user_nm}_PRIVS'
    # wh_name = f'{db_name}_USER_WH_M'

    # if config.env=="dev" or config.env=="sit":
    #     account = "st69414.us-east-2.privatelink"
    #     HOST = "carelon-eda-nonprod.privatelink.snowflakecomputing.com"
    # elif config.env=="uat" or config.env=="preprod":
    #     account = "jib90126.us-east-1.privatelink"
    #     HOST = "carelon-eda-preprod.privatelink.snowflakecomputing.com"
    # else:
    #     account = "gcb59607.us-east-1.privatelink"
    #     HOST = "carelon-eda-prod.privatelink.snowflakecomputing.com"
 
    
    # sf_conn = snowflake.connector.connect(
    #     user=user_nm,
    #     password=user_pwd,
    #     account=account,
    #     host=HOST,
    #     port=443,
    #     warehouse=wh_name,#"POC_SPC_SNOWPARK_WH",#"DOC_AI_WH",
    #     role=role_nm,#"POC_SPC_SNOWPARK_CONTAINER_ROLE",#"DOC_AI_BUSINESS_USER",
    #     #authenticator='externalbrowser'
    #     authenticator="https://portalsso.elevancehealth.com/snowflake/okta"
    # )
    try:
        # Execute the SQL query
        cs = sf_conn.cursor()
        cs.execute(query.exec_sql)

        # Fetch column names and rows
        column_names = [desc[0] for desc in cs.description]
        column_types = [desc[1] for desc in cs.description]
        print("col",column_names)
        print("col",column_types)
        rows = cs.fetchall()

        # Convert rows to a list of dictionaries (records)
        result_json = [
            {
                column: (
                    float(value) if isinstance(value, Decimal) else
                    value.isoformat() if isinstance(value, (datetime, date)) else
                    value
                )
                for column, value in zip(column_names, row)
            }
            for row in rows
        ]

        cs.close()

        # Return the result as JSON
        return JSONResponse(content=result_json)

    except Exception as e:
        logger.error(f"Error executing SQL query: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="An error occurred while executing the SQL query."
        )

# @route_utils.post("/txt2sql/run_sql_query")
# async def run_sql_query(
#     query: Annotated[SqlExecModel, Body(embed=True)],
#     config: Annotated[GenAiEnvSettings, Depends(get_config)],
#     logger: Annotated[Logger, Depends(get_logger)],
#     background_tasks: BackgroundTasks
# ):
#     """
#     Execute an SQL query in Snowflake and return the results as JSON.
#     """
#     api_validator = ValidApiKey()
#     if api_validator(query.api_key, query.aplctn_cd, query.app_id):
#         try:
#             # Establish Snowflake connection
#             sf_conn = SnowFlakeConnector.get_conn(
#                 query.aplctn_cd,
#                 query.app_lvl_prefix,
#                 query.session_id
#             )
#         except DatabaseError as e:
#             raise HTTPException(
#                 status_code=status.HTTP_403_FORBIDDEN,
#                 detail="User not authorized to resources"
#             )

#         try:
#             # Execute the SQL query
#             cs = sf_conn.cursor()
#             cs.execute(query.exec_sql)

#             # Fetch the results into a DataFrame
#             df = cs.fetch_pandas_all()
#             df = df.fillna(0)  # Replace NaN values with 0

#             # Convert date and datetime objects to strings
#             for column in df.select_dtypes(include=["datetime", "datetimetz"]).columns:
#                 df[column] = df[column].dt.strftime('%Y-%m-%d %H:%M:%S')  # Format datetime
#             for column in df.select_dtypes(include=["object"]).columns:
#                 df[column] = df[column].apply(lambda x: x.isoformat() if isinstance(x, (datetime, date)) else x)

#             cs.close()

#             # Convert DataFrame to JSON
#             result_json = df.to_dict(orient="records")
#             return JSONResponse(content=result_json)

#         except Exception as e:
#             logger.error(f"Error executing SQL query: {e}")
#             raise HTTPException(
#                 status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
#                 detail="An error occurred while executing the SQL query."
#             )
#     else:
#         raise HTTPException(
#             status_code=status.HTTP_401_UNAUTHORIZED,
#             detail="Unauthenticated user"
#         )

import httpx
@route_utils.post("/txt2sql/generate_vega_lite_json")
async def generate_vegalite(
    query: Annotated[SqlExecModel, Body(embed=True)],
    config: Annotated[GenAiEnvSettings, Depends(get_config)],
    logger: Annotated[Logger, Depends(get_logger)],
    background_tasks: BackgroundTasks
):
    api_validator = ValidApiKey()
    if api_validator(query.api_key, query.aplctn_cd, query.app_id):
        try:
            # Establish Snowflake connection
            sf_conn = SnowFlakeConnector.get_conn(
                query.aplctn_cd,
                query.app_lvl_prefix,
                query.session_id
            )
        except DatabaseError as e:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="User not authorized to resources"
            )
    # user_nm = query.user_nm
    # user_pwd = query.user_pwd
    # db_name = query.database_nm
    # role_nm = "D01_RSTRCTRD_EDA_GENAI_SUPPORTCBT_CORTEX_DVLPR_NOGBD"#f'{user_nm}_PRIVS'
    # wh_name = f'{db_name}_USER_WH_M'

    # if config.env=="dev" or config.env=="sit":
    #     account = "st69414.us-east-2.privatelink"
    #     HOST = "carelon-eda-nonprod.privatelink.snowflakecomputing.com"
    # elif config.env=="uat" or config.env=="preprod":
    #     account = "jib90126.us-east-1.privatelink"
    #     HOST = "carelon-eda-preprod.privatelink.snowflakecomputing.com"
    # else:
    #     account = "gcb59607.us-east-1.privatelink"
    #     HOST = "carelon-eda-prod.privatelink.snowflakecomputing.com"
 
    
    # sf_conn = snowflake.connector.connect(
    #     user=user_nm,
    #     password=user_pwd,
    #     account=account,
    #     host=HOST,
    #     port=443,
    #     warehouse=wh_name,#"POC_SPC_SNOWPARK_WH",#"DOC_AI_WH",
    #     role=role_nm,#"POC_SPC_SNOWPARK_CONTAINER_ROLE",#"DOC_AI_BUSINESS_USER",
    #     #authenticator='externalbrowser'
    #     authenticator="https://portalsso.elevancehealth.com/snowflake/okta"
    # )
    try:
        # Execute the SQL query
        cs = sf_conn.cursor()
        cs.execute(query.exec_sql)

        # Fetch column names and rows
        column_names = [desc[0] for desc in cs.description]
        column_types = [desc[1] for desc in cs.description]
        #print("col",column_names)
        #print("col",column_types)
        type_mapping = {
            0: "int",
            2: "string",
            3: "date"
        }

        schema_obj = {
            "title": "TABLE_SCHEMA",
            "type": "object",
            "properties": {}
        }

        for col_name, col_type in zip(column_names, column_types):
            mapped_type = type_mapping.get(col_type, "string")  # default to string if unknown
            schema_obj["properties"][col_name] = {"type": mapped_type}
        rows = cs.fetchall()
        result_json = [
            {
                column: (
                    float(value) if isinstance(value, Decimal) else
                    value.isoformat() if isinstance(value, (datetime, date)) else
                    value
                )
                for column, value in zip(column_names, row)
            }
            for row in rows
        ]
        print("sample records", result_json)
        res_partial = result_json[:2]
        print("Partial Res", res_partial)
        query = query.prompt

        # data-source:
        # {res_partial}
        prompt = f"""
        You are an expert in data visualization.
        Your job is to suggest a most suitable chart based on the data-schema(which holds metadata) and data-query(which is prompt) provided and data-source (which is data sample) generate Vega-Lite json for the same.   
        data-schema: 
        {schema_obj}
        data-query: 
        {query}
        Also we will be appending full dataframe data once the json is generated.
        Please consider the properties from the provided schema for the generation of Vega-Lite json.
        """
        
        headers = {
            'accept': 'application/json',
            'Content-Type': 'application/json'
        }
        print("Full_prompt", prompt)
        body = {
            "query": {
                "aplctn_cd": "edagnai",
                "app_id": "edadip",
                "api_key": "78a799ea-a0f6-11ef-a0ce-15a449f7a8b0",
                "method": "cortex",
                "model": "llama3.1-70b",
                "sys_msg": "You are powerful AI assistant in providing accurate answers always. Be Concise in providing answers based on context.",
                "limit_convs": "0",
                "prompt": {
                "messages": [
                    {
                    "role": "user",
                    "content": prompt
                    }
                ]
                },
                "app_lvl_prefix": "supportcbt_dml",
                "user_id": "",
                "session_id": "0947b240-9447-4af7-8367-65e6cc8fa5d9"
            }
        }
        url = 'https://sfassist.edagenaidev.awsdns.internal.das/api/cortex/complete'
        response = httpx.post(
            url=url,
            headers=headers,json=body,timeout=None
        )
        print("Full_body", body)
        if response.status_code == 200:
            print(response.text)
            response_text = response.text
            start_index = response_text.find("```") + len("```json") 
            end_index = response_text.find("```",start_index)
            res = response_text[start_index:end_index].strip()
            vega_json=json.loads(res)
            print(vega_json)
            vega_json["data"] = {
                "values": result_json }
            #return JSONResponse(content=res)
            print(vega_json)
            return vega_json
        else:
                print("Vega-Lite JSON not found.")
            #return JSONResponse(content=response.text)

    except Exception as e:
        logger.error(f"Error executing SQL query: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail={e} #"An error occurred while executing the SQL query."
        )

@route_utils.post("/update_feedback/")
async def update_feedback(
    fdbck_id: str,
    session_id: Optional[str],
    feedbk_actn_txt: Optional[str] = None,
    feedbk_cmnt_txt: Optional[str] = None
):
    """
    Update feedback in the audit table and return a success message once the update is complete.
    """
    try:
        # Call the update_log_response function directly
        result = update_log_response(fdbck_id, feedbk_actn_txt, feedbk_cmnt_txt, session_id)
        return {"status": "success", "message": result}
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"An error occurred while updating feedback: {str(e)}"
        )

@route_utils.post("/upload_file/")
async def upload_file(
    query: Annotated[str, Form()],
    config: Annotated[GenAiEnvSettings, Depends(get_config)],
    logger: Annotated[Logger, Depends(get_logger)],
    files: List[UploadFile]
):
    """Upload and process multiple CSV, PDF, DOCX, or TXT files."""
    query = json.loads(query)
    api_validator = ValidApiKey()
    if api_validator(query['api_key'], query['aplctn_cd'], query['app_id']):
        sf_conn = SnowFlakeConnector.get_conn(
            query['aplctn_cd'],
            query['app_lvl_prefix'],
            query['session_id'],
        )
        res = await read_file_extract(files,sf_conn,app_nm=query['app_nm'])
        return res
    else: 
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="unauthenticated user"
        )
    
@route_utils.post("/get_app_db_schm_lst")
async def list_app_database_schema(
    query: Annotated[PageLoadModel, Body(embed=True)],
    config: Annotated[GenAiEnvSettings, Depends(get_config)],
    logger: Annotated[Logger, Depends(get_logger)],
    background_tasks: BackgroundTasks
):
    api_validator = ValidApiKey()
    if api_validator(query.api_key, query.aplctn_cd, query.app_id):
        try:
            # Establish Snowflake connection
            sf_conn = SnowFlakeConnector.get_conn(
                query.aplctn_cd,
                query.app_lvl_prefix,
                query.session_id
            )
        except DatabaseError as e:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="User not authorized to resources"
            )
    db_name = get_sf_database_name(logger,query.aplctn_cd,config.env,config.region_name,prefix=query.app_lvl_prefix)
    schema_sql = f"SHOW SCHEMAS in {db_name}"
    #warehouse_nm = f"{db_name}_USER_WH_"
    try:
        # Execute the SQL query
        cs = sf_conn.cursor()
        cs.execute(schema_sql)
 
        # Fetch column names and rows
        column_names = [desc[0] for desc in cs.description]
        rows = cs.fetchall()
 
        schema_nm  = [sublist[1] for sublist in rows]
        cs.close()
 
        fetch_details = {"database":[db_name],"schema_nm":schema_nm}
        return fetch_details
 
    except Exception as e:
        logger.error(f"Error executing SQL query: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="An error occurred while executing the SQL query."
        )
    
@route_utils.post("/get_agent_lst")
async def list_app_database_schema(
    query: Annotated[AgentListModel, Body(embed=True)],
    config: Annotated[GenAiEnvSettings, Depends(get_config)],
    logger: Annotated[Logger, Depends(get_logger)],
    background_tasks: BackgroundTasks
):
    api_validator = ValidApiKey()
    if not api_validator(query.api_key, query.aplctn_cd, query.app_id):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Unauthenticated user"
        )
    try:
        # Establish Snowflake connection
        try:
            sf_conn = SnowFlakeConnector.get_conn(
                query.aplctn_cd,
                query.app_lvl_prefix,
                query.session_id
            )
        except DatabaseError as e:
            logger.error(f"Database connection error: {e}")
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="User not authorized to resources"
            )
        db_name = query.database_nm
        schema_nm = query.schema_nm
        headers = {
            "Authorization": f'Snowflake Token="{sf_conn.rest.token}"',
            "Content-Type": "application/json",
            "Accept": "application/json"
        }
        base_url = getattr(config.AGENTWO, "{}_host".format(config.env))
        url = f"{base_url}/api/v2/databases/{db_name}/schemas/{schema_nm}/agents"
        try:
            resp = requests.get(url=url, headers=headers)
        except requests.RequestException as e:
            logger.error(f"Request to Cortex Agents API failed: {e}")
            raise HTTPException(
                status_code=status.HTTP_502_BAD_GATEWAY,
                detail=f"Failed to connect to Cortex Agents API: {e}"
            )
        if resp.status_code == 200:
            try:
                agents = resp.json()
            except Exception as e:
                logger.error(f"Failed to parse agents JSON: {e}")
                raise HTTPException(
                    status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                    detail="Failed to parse agents response."
                )
            agent_names = [agent["name"] for agent in agents if "name" in agent]
            return {"agent_names": agent_names}
        else:
            logger.error(f"Cortex Agents API error: {resp.status_code} {resp.text}")
            raise HTTPException(
                status_code=resp.status_code,
                detail=f"Cortex Agents API error: {resp.text}"
            )
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Unexpected error in get_agent_lst: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="An unexpected error occurred while fetching agent list."
        )

@route_utils.get("/prompts/{aplctn_cd}")
async def get_prompts(aplctn_cd: str,
                config: Annotated[GenAiEnvSettings, Depends(get_mcp_config)],
                logger: Annotated[Logger, Depends(get_logger)]):
    print("con",config)
    print("app",aplctn_cd)
    try:
        async with sse_client(config["server"]["SSE_URL"]) as connection:
            print("conn",connection)
            async with ClientSession(*connection) as session:
                await session.initialize()
                print("Session", session)
                uri=f"genaiplatform://{aplctn_cd}/prompts"
                result = await session.read_resource(f"genaiplatform://{aplctn_cd}/prompts") 
                print("res", result)
                return result
    except HTTPException as e:
        logger.error(f"Request error in get_prompts: {e}")
        raise e
    except Exception as e:
        logger.error(f"Unexpected error in get_prompts: {e}")
        print("exce",e)
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail=str(e)
        )

@route_utils.get("/frequent_questions/{aplctn_cd}")
async def get_frequent_questions(aplctn_cd: str,
                config: Annotated[GenAiEnvSettings, Depends(get_mcp_config)],
                logger: Annotated[Logger, Depends(get_logger)]):
    try:
        async with sse_client(config["server"]["SSE_URL"]) as connection:
            async with ClientSession(*connection) as session:
                await session.initialize()
                result = await session.read_resource(f"genaiplatform://{aplctn_cd}/frequent_questions")
                return result
    except HTTPException as e:
        logger.error(f"Request error in get_frequent_questions: {e}")
        raise e
    except Exception as e:
        logger.error(f"Unexpected error in get_frequent_questions: {e}")
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail=str(e)
        )

@route_utils.post("/add_prompt")
async def add_prompt(data: PromptModel,
                config: Annotated[GenAiEnvSettings, Depends(get_mcp_config)],
                logger: Annotated[Logger, Depends(get_logger)]):
    try:
        async with sse_client(config["server"]["SSE_URL"]) as connection:
            async with ClientSession(*connection) as session:
                await session.initialize()
                result = await session.call_tool(name="add-prompts", arguments={
                    "uri": data.uri,
                    "prompt": data.prompt
                })
                return result
    except HTTPException as e:
        logger.error(f"Request error in add_prompt: {e}")
        raise e
    except Exception as e:
        logger.error(f"Unexpected error in add_prompt: {e}")
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail=str(e)
        )

@route_utils.post("/add_frequent_question")
async def add_frequent_question(data: FrequentQuestionModel,
                config: Annotated[GenAiEnvSettings, Depends(get_mcp_config)],
                logger: Annotated[Logger, Depends(get_logger)]):
    try:
        async with sse_client(config["server"]["SSE_URL"]) as connection:
            async with ClientSession(*connection) as session:
                await session.initialize()
                result = await session.call_tool(name="add-frequent-questions", arguments={
                    "uri": data.uri,
                    "questions": data.questions
                })
                return result
    except HTTPException as e:
        logger.error(f"Request error in add_frequent_question: {e}")
        raise e
    except Exception as e:
        logger.error(f"Unexpected error in add_frequent_question: {e}")
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail=str(e)
        )
    
@route_utils.post("/create_agent_thread")
async def create_agent_thread(
    query: Annotated[CreateThreadModel, Body(embed=True)],
    config: Annotated[GenAiEnvSettings, Depends(get_config)],
    logger: Annotated[Logger, Depends(get_logger)],
    background_tasks: BackgroundTasks
):
    api_validator = ValidApiKey()
    if not api_validator(query.api_key, query.aplctn_cd, query.app_id):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Unauthenticated user"
        )
    try:
        sf_conn = SnowFlakeConnector.get_conn(
        query.aplctn_cd,
        query.app_lvl_prefix,
        query.session_id)
        origin_application = "DataFlyWheel_APP"
        headers = {
                "Authorization": f'Snowflake Token="{sf_conn.rest.token}"',
                "Content-Type": "application/json",
                "Accept": "application/json"
            }
        config = get_config()
        base_url = getattr(config.AGENTWO, "{}_host".format(config.env))
        url = f"{base_url}/api/v2/cortex/threads?origin_application={origin_application}"
        payload = {
            "origin_application": origin_application
        }
        response = requests.post(url, headers=headers, json=payload)
        if response.status_code == 200:
            data = response.json()
            logger.info(f"Create thread Response: {data}")
            thread_id = data['thread_id']
            update_url = f"{base_url}/api/v2/cortex/threads/{thread_id}"
            payload = {
            "thread_name": f"{query.user_nm}-{query.session_id[0:10]}"}
            upd_response = requests.post(update_url, headers=headers, json=payload)
            print(upd_response.text)
            if upd_response.status_code == 200:
                logger.info("Thread name updated successfully")
            else:
                logger.error(f"Failed to update thread name: {upd_response.text}")
            return data
        else:
            raise Exception(f"Thread creation failed: {response.text}")
    except HTTPException as e:
        logger.error(f"Request error in get_prompts: {e}")
        raise e
    except Exception as e:
        logger.error(f"Unexpected error in get_prompts: {e}")
        print("exce",e)
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail=str(e)
        )