def fetch_last_n_jsons(history, user_message, assistant_response, limit_convs):
    """Add a user-assistant message pair to the conversation history with a pair limit"""
    
    # If limit_convs is 0, return an empty history (no conversation stored)
    if limit_convs == 0:
        return []

    # Create message pair
    message_pair = {
        'user': user_message,
        'assistant': assistant_response
    }

    # Add the pair to history
    history.append(message_pair)

    # If the number of pairs exceeds the limit, keep only the most recent pairs
    if len(history) > limit_convs:
        history = history[-limit_convs:]

    return history

def get_conv_response(messages_json, limit_convs=None):
    
    # Handle messages_json as a list of Prompt objects, possibly only user prompts
    conversation_history = []
    i = 0
    while i < len(messages_json):
        user_prompt = messages_json[i]
        if hasattr(user_prompt, 'role') and user_prompt.role == 'user':
            if i + 1 < len(messages_json):
                assistant_prompt = messages_json[i + 1]
                if hasattr(assistant_prompt, 'role') and assistant_prompt.role == 'assistant':
                    conversation_history.append({
                        'user': user_prompt.content,
                        'assistant': assistant_prompt.content
                    })
                    i += 2
                    continue
            # If no assistant response, just add user message
            conversation_history.append({
                'user': user_prompt.content,
                'assistant': None
            })
        i += 1

    last_msg = messages_json[-1]
    INITAL_PROMPT = f"""<|begin_of_text|><|start_header_id|>system<|end_header_id|>

    You are a helpful AI chat assistant with all capabilities.
    Below is the context supplied.{last_msg}
    <|eot_id|>
    """
    new_prompt_template = INITAL_PROMPT + " The chat history is as below \n" + str(conversation_history)
    print("new_prompt_template", new_prompt_template)
    return new_prompt_template
